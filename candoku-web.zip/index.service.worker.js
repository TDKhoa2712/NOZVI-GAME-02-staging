// Retires the service worker an earlier build of this game installed. The current build runs
// without one; a returning browser checks the old worker's URL for updates, gets this file, and
// it deletes this game's caches, unregisters itself and reloads open pages from the network.
// Only caches named with this game's prefix are touched: other games share the origin.
const PREFIX = "CanDoKu-sw-cache-";

self.addEventListener('install', () => self.skipWaiting());

self.addEventListener('activate', (event) => {
	event.waitUntil((async () => {
		const keys = await caches.keys();
		await Promise.all(keys.filter((key) => key.startsWith(PREFIX)).map((key) => caches.delete(key)));
		await self.clients.claim();
		await self.registration.unregister();
		const pages = await self.clients.matchAll({ type: 'window' });
		await Promise.all(pages.map((page) => page.navigate(page.url).catch(() => null)));
	})());
});
